<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('teacher_choice.css')); ?>">
    <title>Teacher choice</title>
</head>
<body>
    <header>
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('image/logo_Edubooking-removebg-preview.png')); ?>" alt="Home" class="home-button-img">
        </a>
        <a href="<?php echo e(route('login')); ?>" class="nav-link button">Login</a> 
    </header>

    <a href="<?php echo e(route('home')); ?>">&larr; Return</a>
   
    <div class="whole_page">
        <div class="container">
            <h2>You are a student, please select a teacher:</h2>
            <form action="<?php echo e(route('submit-teacher')); ?>" method="POST">
            <?php echo csrf_field(); ?>
                <label for="user" class="label">Choose a teacher:</label>
                <select name="user_id" id="user" class="select-dropdown">
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="submit_button">Submit</button>
            </form>
        </div>
    </div>

    
</body>
</html>
<?php /**PATH C:\Users\Utilisateur\YNOV\B2\Projet B2 DEV\EduBooking\Projet-EduBooking-B2\{EduBooking}\resources\views/student_teacher_choice.blade.php ENDPATH**/ ?>