<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Appointment</title>
    <link rel="stylesheet" href="<?php echo e(asset('header.css')); ?>">
</head>
<body>
    <header>
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('image/logo_Edubooking-removebg-preview.png')); ?>" alt="Home" class="home-button-img">
        </a>
        <a href="<?php echo e(route('login')); ?>" class="nav-link button">Login</a>
    </header>

    <form action="<?php echo e(route('store_appointment')); ?>" method="POST">
    <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
        <input type="hidden" name="teacher_user_id" value="<?php echo e($teacherId); ?>">

        <label for="subject_id">Subject:</label>
        <select id="subject_id" name="subject_id" required>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="appointment_day">Day:</label>
        <input type="date" id="appointment_day" name="appointment_day" required>

        <script>                                                            
            const input = document.getElementById('appointment_day');      
            input.addEventListener('input', function (e) {
                const day = new Date(this.value).getDay();                  // disable weekends
                if (day === 0 || day === 6) {
                    alert("Weekends are not selectable.");
                    this.value = ''; 
                }                                                       
            });
        </script>                                                           


        <label for="user_comment">Comment:</label>
        <input type="text" id="user_comment" name="user_comment" required>

        <button href="<?php echo e(route('login')); ?>" type="submit">Submit</button>
    </form>

</body>
</html>
<?php /**PATH C:\Users\Utilisateur\YNOV\B2\Projet B2 DEV\EduBooking\Projet-EduBooking-B2\{EduBooking}\resources\views/create_appointment.blade.php ENDPATH**/ ?>