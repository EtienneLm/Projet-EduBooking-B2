<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('header.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('app.css')); ?>"> -->
    <title>Teacher Page</title>
</head>
<body>
    <header>
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('image/logo_Edubooking-removebg-preview.png')); ?>" alt="Home" class="home-button-img">
        </a>
        <a href="<?php echo e(route('login')); ?>" class="nav-link button">Login</a> 
    </header>

    <a href="<?php echo e(route('home')); ?>">&larr; Return</a>


    <h1>Here are all of your appointments : </h1>
    <form action="<?php echo e(route('delete_appointment')); ?>" method="POST">
    <?php echo csrf_field(); ?>
        <select name="appointment_id" id="appointment">
        <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($appointment->id); ?>">
                <?php echo e($appointment->appointment_day); ?> - <?php echo e($appointment->user->name); ?> - <?php echo e($appointment->user_comment); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option>No appointments available.</option>
        <?php endif; ?>
        </select>
        <button type="submit" class="btn btn-danger">Delete Selected Appointment</button>
    </form>




    <h3> --------------------------------------------------------- </h3>

    
</body>
</html>
<?php /**PATH C:\Users\Utilisateur\YNOV\B2\Projet B2 DEV\EduBooking\Projet-EduBooking-B2\{EduBooking}\resources\views/teacher_page.blade.php ENDPATH**/ ?>