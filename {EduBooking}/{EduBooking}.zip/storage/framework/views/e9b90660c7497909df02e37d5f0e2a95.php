<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('main.css')); ?>">
    <title>Main Page</title>
</head>
<body>
    <header>
        <a href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('image/logo_Edubooking-removebg-preview.png')); ?>" alt="Home" class="home-button-img">
        </a>
        <?php if(auth()->check()): ?>
            <a href="<?php echo e(route('logout')); ?>" class="nav-link button">Logout</a>
            <span>Welcome, <?php echo e(auth()->user()->name); ?>!</span>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="nav-link button">Login</a> 
        <?php endif; ?>
    </header>

    <div class="container">
        <div class="card">
            <h2>Je suis étudiant</h2>
            <div class="card-content">
                <p>Bienvenue, étudiant!</p>
                <p>Choisissez cette option si vous êtes un étudiant inscrit.</p>
            </div>
            <a href="<?php echo e(url('student_teacher_choice')); ?>">Continuer en tant qu'étudiant</a>
        </div>
        <div class="card">
            <h2>Je suis enseignant</h2>
            <div class="card-content">
                <p>Bienvenue, enseignant!</p>
                <p>Choisissez cette option si vous êtes un enseignant.</p>
            </div>
            <a href="<?php echo e(url('teacher_page')); ?>">Continuer en tant qu'enseignant</a>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Utilisateur\YNOV\B2\Projet B2 DEV\EduBooking\Projet-EduBooking-B2\{EduBooking}\resources\views/main.blade.php ENDPATH**/ ?>